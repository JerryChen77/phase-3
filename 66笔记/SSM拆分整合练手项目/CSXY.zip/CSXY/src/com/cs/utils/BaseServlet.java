package com.cs.utils;

import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

//把BserseServlet 成为后端的唯一入口
public class BaseServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp){
        String method = req.getParameter("method");
        Object resultMap =null;
//        通过反射机制代替目标类执行方法
        try {
//            利用反射机制获取子类的class对象，这个对象里包含了所有属性以及方法，所以用getMethod去获取方法的对象
            Method method1 = this.getClass().getMethod(method, HttpServletRequest.class, HttpServletResponse.class);

//            利用反射机制，执行已经获取的方法的对象method1
            resultMap = method1.invoke(this, req, resp);

//            把结果集转化为json对象，返回给前端
            String string = JSON.toJSONString(resultMap);

            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().print(string);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
        doPost(req, resp);
    }
}
