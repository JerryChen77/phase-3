package com.cs.dao;

import com.cs.Entity.User;

import java.util.List;

public interface UserDao {

    public User login(User user);

    public int addUser(User user);

    public List<User> selectAllUser();

    public int updateUser (User user);

    public int deleteUser(int id);
}
