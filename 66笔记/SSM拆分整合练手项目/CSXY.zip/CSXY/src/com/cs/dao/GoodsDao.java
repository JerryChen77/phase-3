package com.cs.dao;

import com.cs.Entity.Goods;
import com.cs.Entity.GoodsType;
import com.cs.Entity.Record;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GoodsDao {
//    查询所有商品
    public List<Goods> selectAllGoods();

//    查询所有商品类型
    public List<GoodsType> selectAllGoodsType();

//    添加商品类型
    public int addGoodsType(GoodsType goodsType);

//    修改商品类型
    public int updateGoodsType(GoodsType goodsType);

//    删除商品类型
    public int deleteGoodsType(int id);

//    添加商品
    int addGoods(Goods goods);

//添加用户和商品的中间表
    int addGoods_user(@Param("uid") int uid,@Param("gid") int gid);

    //添加商品类型和商品的中间表
//    如果mybatis dao 层方法有两个或以上个参数，需要加上注解
    int addGoods_goodsType(@Param("gid") int gid, @Param("tid") int tid);

//    通过商品名查询商品
    Goods selectGoodsByName(String name);

//    通过商品类型名查询商品类型
    GoodsType selectGoodsTypeByName(String name);

    int updateRepertory(@Param("repertory")int repertory,@Param("id")int id);

    int addRecord(Record record);

    Goods selectGoodsByID(int id);

    List<Record> selectAllRecord();
}
