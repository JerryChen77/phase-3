package com.cs.Entity;

public class Goods {
    private int id;
    private String name;
    private String price;
    private int repertory;
    private int u_id;
    private String u_name;
    private String type;
    private int typeName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getRepertory() {
        return repertory;
    }

    public void setRepertory(int repertory) {
        this.repertory = repertory;
    }

    public int getU_id() {
        return u_id;
    }

    public void setU_id(int u_id) {
        this.u_id = u_id;
    }

    public String getU_name() {
        return u_name;
    }

    public void setU_name(String u_name) {
        this.u_name = u_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getTypeName() {
        return typeName;
    }

    public void setTypeName(int typeId) {
        this.typeName = typeId;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price='" + price + '\'' +
                ", repertory=" + repertory +
                ", u_id=" + u_id +
                ", u_name='" + u_name + '\'' +
                ", type='" + type + '\'' +
                ", typeName=" + typeName +
                '}';
    }
}
