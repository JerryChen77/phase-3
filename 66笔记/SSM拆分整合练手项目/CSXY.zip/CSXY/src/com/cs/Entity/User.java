package com.cs.Entity;

public class User {
    private String username;
    private String password;
    private int id;
    private String name;
    private String tel;
    private String address;
//    1:用户 2：管理员 3：商家
    private int type;
    private int u_delete;

    public User() {
    }

    public User(String username, String password, int id, String name, String tel, String address, int type, int u_delete) {
        this.username = username;
        this.password = password;
        this.id = id;
        this.name = name;
        this.tel = tel;
        this.address = address;
        this.type = type;
        this.u_delete = u_delete;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getU_delete() {
        return u_delete;
    }

    public void setU_delete(int u_delete) {
        this.u_delete = u_delete;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", tel='" + tel + '\'' +
                ", address='" + address + '\'' +
                ", type=" + type +
                ", u_delete=" + u_delete +
                '}';
    }
}
