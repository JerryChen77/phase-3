package com.cs.Entity;

import java.util.List;

public class ResultMap {
//    所有属性全部私有化
//    外部访问的话只能通过getter和setter
//    一定要有有参和无参构造方法 还要有get和set方法

    //	alt+shift+s+r  快速生成get set方法
    //	alt+shift+s+o 生成带参构造
    //	alt+/ 生成无参构造器
    private boolean status;
    private String message;
    private Object data;
    private List list;
    private long count;
    private int code;


    public ResultMap() {
    }

    public ResultMap(boolean status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
