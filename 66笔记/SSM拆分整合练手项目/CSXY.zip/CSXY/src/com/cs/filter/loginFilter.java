package com.cs.filter;

import com.cs.Entity.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/index_v1.jsp")
public class loginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
//        初始化方法
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;

        User loginUser = (User) req.getSession().getAttribute("loginUser");

        if (loginUser == null) {
//            证明没有登录
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        } else {
            filterChain.doFilter(req,resp);
        }
    }

    @Override
    public void destroy() {
//        销毁方法
    }
}
