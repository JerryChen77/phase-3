package com.cs.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.cs.Entity.ResultMap;
import com.cs.Entity.User;
import com.cs.services.UserService;
import com.cs.utils.BaseServlet;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.sf.jsqlparser.expression.JsonExpression;

@WebServlet("/user")
public class UserServlet extends BaseServlet {
    UserService userService = new UserService();

    public ResultMap login(HttpServletRequest req, HttpServletResponse resp) {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        ResultMap resultMap = new ResultMap();

        User userResult = userService.login(user);
        if (userResult == null) {//登录失败
            resultMap.setStatus(false);
            resultMap.setMessage("servlet:登录失败");
        } else {//登录成功
            resultMap.setStatus(true);
//			获取session
            req.getSession().setAttribute("loginUser", userResult);
        }
        return resultMap;
    }

    public ResultMap addUser(HttpServletRequest req, HttpServletResponse resp) {
//	    把接收到json格式的数据直接转化为后端对象 第一个参数是前端传过来的值的字段名，第二个参数是要转化成的实体类的class对象
        String addUserValue = req.getParameter("addUserValue");
        User user = JSON.parseObject(addUserValue, User.class);
        System.out.println(user);
//        查询数据库得到的结果
        int i1 = userService.addUser(user);

        ResultMap resultMap = new ResultMap();
//        返回结果为1，就代表sql操作影响了一行，代表添加成功
        if (i1 == 1) {
            resultMap.setStatus(true);
        } else {
            resultMap.setStatus(false);
        }

        return resultMap;
    }

    public ResultMap selectAllUser(HttpServletRequest req, HttpServletResponse resp) {
        ResultMap resultMap = new ResultMap();
        try {
//            获取前端分页的数据，当前是第几页，每页有多少条数据
            int page = Integer.parseInt(req.getParameter("page"));
            int limit = Integer.parseInt(req.getParameter("limit"));
//          开启分页
            Page<Object> objects = PageHelper.startPage(page, limit);
//            查询出所有的用户 把结果包装成分页数据
            List<User> users = userService.selectAllUser();
            PageInfo<User> userPageInfo = new PageInfo<>(users);

            if (users.size() == 0) {
//                前端指定0为陈宫
                resultMap.setCode(1);
                resultMap.setMessage("查询失败，你运气太差了");
            } else {
                resultMap.setList(users);
                resultMap.setCode(0);
                resultMap.setCount(userPageInfo.getTotal());
                resultMap.setMessage("查询成功，数据总量为：" + userPageInfo.getTotal());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return resultMap;
    }

    public ResultMap updateUser(HttpServletRequest req, HttpServletResponse resp) {
        User user = JSON.parseObject(req.getParameter("formValue"), User.class);
        int i = 0;
        ResultMap resultMap = new ResultMap();
        try {
            i = userService.updateUser(user);
            System.out.println("改变了 ： " + i + " 行");
            if (i == 1) {
                resultMap.setStatus(true);
            } else {
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return resultMap;
    }

    public ResultMap deleteUser(HttpServletRequest req, HttpServletResponse resp) {
//	    吧接收到的参数，类型从字符串转化为int
        int id = Integer.parseInt(req.getParameter("id"));
        int i = 0;
        ResultMap resultMap = new ResultMap();
        try {
            i = userService.deleteUser(id);
            System.out.println("改变了 ： " + i + " 行");
            if (i == 1) {
                resultMap.setStatus(true);
            } else {
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return resultMap;
    }

    public ResultMap logOut(HttpServletRequest req, HttpServletResponse resp) {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        ResultMap resultMap = new ResultMap();
        if (loginUser == null) {
        } else {
            loginUser = null;
            req.getSession().setAttribute("loginUser", loginUser);
        }
        if (req.getSession().getAttribute("loginUser") == null) {
            resultMap.setStatus(true);
        } else {
            resultMap.setStatus(false);
        }
        return resultMap;
    }
}
