package com.cs.Servlet;

import com.alibaba.fastjson.JSON;
import com.cs.Entity.*;
import com.cs.services.GoodsService;
import com.cs.utils.BaseServlet;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/goods")
public class GoodsServlet extends BaseServlet {
    GoodsService goodsService = new GoodsService();
    ResultMap resultMap = new ResultMap();


    public ResultMap selectAllGoodsType(HttpServletRequest req, HttpServletResponse resp) {
        try {
//            获取前端分页的数据，当前是第几页，每页有多少条数据
            int page = Integer.parseInt(req.getParameter("page"));
            int limit = Integer.parseInt(req.getParameter("limit"));
//          开启分页
            Page<Object> objects = PageHelper.startPage(page, limit);
//            查询出所有的用户 把结果包装成分页数据
            List<GoodsType> goodsTypes = goodsService.selectAllGoodsType();

//            pageHelper 分页插件
            PageInfo<GoodsType> goodsTypePageInfo = new PageInfo<GoodsType>(goodsTypes);

            if (goodsTypes.size() == 0) {
//                前端指定0为陈宫
                resultMap.setCode(1);
                resultMap.setMessage("查询失败，你运气太差了");
            } else {
                resultMap.setList(goodsTypes);
                resultMap.setCode(0);
//                获取总数据量
                resultMap.setCount(goodsTypePageInfo.getTotal());
                resultMap.setMessage("查询成功，数据总量为：" + goodsTypePageInfo.getTotal());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap selectAllGoodsTypeNoPage(HttpServletRequest req, HttpServletResponse resp) {
        try {
            List<GoodsType> goodsTypes = goodsService.selectAllGoodsType();


            if (goodsTypes.size() == 0) {
//                前端指定0为成功
                resultMap.setStatus(false);
            } else {
                resultMap.setStatus(true);
                resultMap.setList(goodsTypes);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap addGoodsType(HttpServletRequest req, HttpServletResponse resp) {
        req.getParameter("addGoodsTypeValue");
        GoodsType addGoodsTypeValue = JSON.parseObject(req.getParameter("addGoodsTypeValue"), GoodsType.class);

        try {
            int i = goodsService.addGoodsType(addGoodsTypeValue);
            if (i == 1) {
                resultMap.setStatus(true);
            } else {
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap updateGoodsType(HttpServletRequest req, HttpServletResponse resp) {
        GoodsType addGoodsTypeValue = JSON.parseObject(req.getParameter("formValue"), GoodsType.class);

        try {
            int i = goodsService.updateGoodsType(addGoodsTypeValue);
            if (i == 1) {
                resultMap.setStatus(true);
            } else {
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap deleteGoodsType(HttpServletRequest req, HttpServletResponse resp) {
        int i1 = Integer.parseInt(req.getParameter("id"));
        try {
            int i = goodsService.deleteGoodsType(i1);
            if (i == 1) {
                resultMap.setStatus(true);
            } else {
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }


    public ResultMap selectAllGoods(HttpServletRequest req, HttpServletResponse resp) {
        try {
//            获取前端分页的数据，当前是第几页，每页有多少条数据
            int page = Integer.parseInt(req.getParameter("page"));
            int limit = Integer.parseInt(req.getParameter("limit"));
//          开启分页
            Page<Object> objects = PageHelper.startPage(page, limit);
//            查询出所有的用户 把结果包装成分页数据
            List<Goods> goodes = goodsService.selectAllGoods();

//            pageHelper 分页插件
            PageInfo<Goods> goodsTypePageInfo = new PageInfo<Goods>(goodes);

            if (goodes.size() == 0) {
//                前端指定0为陈宫
                resultMap.setCode(1);
                resultMap.setMessage("查询失败，你运气太差了");
            } else {
                resultMap.setList(goodes);
                resultMap.setCode(0);
//                获取总数据量
                resultMap.setCount(goodsTypePageInfo.getTotal());
                resultMap.setMessage("查询成功，数据总量为：" + goodsTypePageInfo.getTotal());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap addGoods(HttpServletRequest req, HttpServletResponse resp) {
//        把前端传过来的json格式的数据，转化为goods对象
        Goods addGoodsValue = JSON.parseObject(req.getParameter("addGoodsValue"), Goods.class);

        try {
            int i = goodsService.addGoods(addGoodsValue,req);
            if (i == 2) {//添加成功
                resultMap.setStatus(true);
            } else {//添加失败
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap updateRepertory(HttpServletRequest req, HttpServletResponse resp) {
//        接收前端接受的參數
        int nums = Integer.parseInt(req.getParameter("nums"));
        int id = Integer.parseInt(req.getParameter("id"));
        String flag = req.getParameter("flag");
        String name = req.getParameter("name");
        Record record = new Record();
        record.setU_name(((User)req.getSession().getAttribute("loginUser")).getName());
        record.setNums(nums);
        record.setG_id(id);
        record.setFlag(flag);
        record.setName(name);
        try {
            int i = goodsService.updateRepertory(req, record);
            if (i == 2) {//添加成功
                resultMap.setStatus(true);
            } else {//添加失败
                resultMap.setStatus(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public ResultMap selectAllRecord(HttpServletRequest req, HttpServletResponse resp) {
        try {
//            获取前端分页的数据，当前是第几页，每页有多少条数据
            int page = Integer.parseInt(req.getParameter("page"));
            int limit = Integer.parseInt(req.getParameter("limit"));
//          开启分页
            Page<Object> objects = PageHelper.startPage(page, limit);
//            查询出所有的用户 把结果包装成分页数据
            List<Record> records = goodsService.selectAllRecord();

//            pageHelper 分页插件
            PageInfo<Record> goodsTypePageInfo = new PageInfo<Record>(records);

            if (records.size() == 0) {
//                前端指定0为陈宫
                resultMap.setCode(1);
                resultMap.setMessage("查询失败，你运气太差了");
            } else {
                resultMap.setList(records);
                resultMap.setCode(0);
//                获取总数据量
                resultMap.setCount(goodsTypePageInfo.getTotal());
                resultMap.setMessage("查询成功，数据总量为：" + goodsTypePageInfo.getTotal());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

}
