package com.cs.services;

import com.cs.Entity.*;
import com.cs.dao.GoodsDao;
import com.cs.utils.MybatisUtil;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

public class GoodsService {

    public List<GoodsType> selectAllGoodsType() throws IOException {
        List<GoodsType> goodsTypes = MybatisUtil.getSqlSession().getMapper(GoodsDao.class).selectAllGoodsType();
        return goodsTypes;
    }

    public List<Goods> selectAllGoods() throws IOException {
        List<Goods> goods = MybatisUtil.getSqlSession().getMapper(GoodsDao.class).selectAllGoods();
        return goods;
    }

    public int addGoodsType(GoodsType goodsType) throws IOException {
        int i = MybatisUtil.getSqlSession().getMapper(GoodsDao.class).addGoodsType(goodsType);
        return i;
    }

    public int updateGoodsType(GoodsType goodsType) throws IOException {
        int i = MybatisUtil.getSqlSession().getMapper(GoodsDao.class).updateGoodsType(goodsType);
        return i;
    }

    public int deleteGoodsType(int id) throws IOException {
        int i = MybatisUtil.getSqlSession().getMapper(GoodsDao.class).deleteGoodsType(id);
        return i;
    }

    public int addGoods(Goods goods, HttpServletRequest req) throws IOException {
        GoodsDao goodsDao = MybatisUtil.getSqlSession().getMapper(GoodsDao.class);

//        从session里获取已经登陆的用户
        User loginUser = (User) req.getSession().getAttribute("loginUser");
//        把已经登录存在于session里的的用户获取出来，把用户名设置到商品对象里
        goods.setU_name(loginUser.getName());
//        通过mybatis操作数据库 添加商品
        int i = goodsDao.addGoods(goods);
        if (i == 1) {//添加商品成功
//        查询此次添加的商品
            Goods goods1 = goodsDao.selectGoodsByName(goods.getName());
//            查询商品类型id
            if (goods1 != null ) {
//                添加商品和商品类型的中间表
                int i1 = goodsDao.addGoods_goodsType(goods1.getId(), Integer.parseInt(goods.getType()));
//                添加商品和用户的中间表
                int i2 = goodsDao.addGoods_user(loginUser.getId(), goods1.getId());
                if (i1 + i2 == 2) {
                    i++;
                }
            }
        }
        return i;
    }

    public int updateRepertory(HttpServletRequest req, Record record) throws IOException {
//        获取当前登录的用户的用户名
        User loginUser = (User) req.getSession().getAttribute("loginUser");

        record.setU_name(loginUser.getName());

        GoodsDao goodsDao = MybatisUtil.getSqlSession().getMapper(GoodsDao.class);

//        定义要修改为的库存数量
        int repertory = 0;
//        查询当前商品的库存数量
        Goods goods = goodsDao.selectGoodsByID(record.getG_id());
        if (record.getFlag().equals("in")) {
            repertory = record.getNums() + goods.getRepertory();
        } else if (record.getFlag().equals("out")){
            repertory = goods.getRepertory() - record.getNums();
        }
//        去数据库修改库存
        System.out.println(repertory);
        int i = goodsDao.updateRepertory(repertory, record.getG_id());
        if (i == 1) {//库存修改成功
//            添加出入库记录
            int i1 = goodsDao.addRecord(record);
            if (i1 == 1) {
                i++;
            }
        }

        return i;
    }

    public List<Record> selectAllRecord() throws IOException {
        GoodsDao goodsDao = MybatisUtil.getSqlSession().getMapper(GoodsDao.class);

        List<Record> records = goodsDao.selectAllRecord();
        return records;
    }
}
