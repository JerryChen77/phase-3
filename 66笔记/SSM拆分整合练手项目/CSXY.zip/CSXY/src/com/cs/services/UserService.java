package com.cs.services;

import com.cs.Entity.User;
import com.cs.dao.UserDao;
import com.cs.utils.MybatisUtil;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class UserService {


    public User login(User user) {
        User userr = new User();
//        IO流去读取Mybatis的配置文件
        try {

//        //利用sqlSession得到接口
            UserDao userDao = MybatisUtil.getSqlSession().getMapper(UserDao.class);

            userr = userDao.login(user);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userr;
    }

    public int addUser(User user) {
        int i = 0;
        try {
            if (user != null) {
                UserDao userDao = MybatisUtil.getSqlSession().getMapper(UserDao.class);
                i = userDao.addUser(user);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return i;
    }

    public List<User> selectAllUser() throws IOException {
        return MybatisUtil.getSqlSession().getMapper(UserDao.class).selectAllUser();
    }

    public int updateUser(User user) throws IOException {
        return MybatisUtil.getSqlSession().getMapper(UserDao.class).updateUser(user);
    }

    public int deleteUser(int id) throws IOException {
        return MybatisUtil.getSqlSession().getMapper(UserDao.class).deleteUser(id);
    }

}
